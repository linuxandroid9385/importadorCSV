import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from pathlib import Path

from config_manager import ConfigManager
from logger_setup import setup_logger
from excel_reader import read_excel_files
from mysql_importer import MySQLImporter
from downtime_simatic_importer import DowntimeSimaticImporter


class ImportadorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Importador Universal MySQL")
        self.geometry("980x680")
        self.files = []

        # Busca config.ini de forma blindada:
        # 1) junto a main.py (src/config.ini)
        # 2) en la raíz del proyecto (../config.ini)
        base_dir = Path(__file__).resolve().parent
        config_path = base_dir / "config.ini"
        if not config_path.exists():
            config_path = base_dir.parent / "config.ini"

        self.cfg = ConfigManager(str(config_path))
        self.logger = setup_logger(self.cfg.log_file(), self.cfg.log_level())
        self.build_ui()

    def build_ui(self):
        header = tk.Label(self, text="Importador Universal MySQL", font=("Segoe UI", 18, "bold"))
        header.pack(pady=12)

        info = tk.Frame(self)
        info.pack(fill="x", padx=15)

        self.lbl_config = tk.Label(
            info,
            text=f"DB: {self.cfg.mysql()['database']} | Tabla Excel: {self.cfg.table()} | Unique keys: {', '.join(self.cfg.unique_keys())}",
            anchor="w"
        )
        self.lbl_config.pack(fill="x")

        buttons = tk.Frame(self)
        buttons.pack(fill="x", padx=15, pady=10)

        tk.Button(buttons, text="Seleccionar Excel", command=self.select_files, height=2).pack(side="left", padx=5)
        tk.Button(buttons, text="Iniciar importación Excel", command=self.start_import, height=2).pack(side="left", padx=5)
        tk.Button(buttons, text="Importar Downtime Simatic", command=self.start_simatic_import, height=2).pack(side="left", padx=5)
        tk.Button(buttons, text="Limpiar lista", command=self.clear_files, height=2).pack(side="left", padx=5)

        self.file_list = tk.Listbox(self, height=8)
        self.file_list.pack(fill="x", padx=15, pady=5)

        tk.Label(self, text="Logs", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=15, pady=(10, 0))
        self.log_box = scrolledtext.ScrolledText(self, height=22)
        self.log_box.pack(fill="both", expand=True, padx=15, pady=10)

    def ui_log(self, msg: str):
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")
        self.update_idletasks()

    def select_files(self):
        files = filedialog.askopenfilenames(
            title="Seleccionar archivos Excel",
            filetypes=[("Excel", "*.xlsx *.xlsm"), ("Todos", "*.*")]
        )
        for file in files:
            if file not in self.files:
                self.files.append(file)
                self.file_list.insert("end", Path(file).name)
        self.ui_log(f"Archivos Excel seleccionados: {len(self.files)}")

    def clear_files(self):
        self.files.clear()
        self.file_list.delete(0, "end")
        self.ui_log("Lista limpiada")

    def start_import(self):
        if not self.files:
            messagebox.showwarning("Sin archivos", "Selecciona al menos un archivo Excel.")
            return
        threading.Thread(target=self.run_import, daemon=True).start()

    def run_import(self):
        importer = None
        try:
            self.ui_log("Iniciando lectura de Excel...")
            df = read_excel_files(self.files, self.cfg.sheet_names(), self.logger)
            self.ui_log(f"Filas detectadas: {len(df)} | Columnas: {len(df.columns)}")
            self.ui_log("Columnas: " + ", ".join(df.columns))

            importer = MySQLImporter(self.cfg.mysql(), self.cfg.table(), self.logger)
            importer.connect()
            total = importer.import_dataframe(
                df=df,
                unique_keys=self.cfg.unique_keys(),
                batch_size=self.cfg.batch_size(),
                auto_create_columns=self.cfg.auto_create_columns()
            )
            self.ui_log(f"IMPORTACIÓN EXCEL FINALIZADA. Registros procesados: {total}")
            messagebox.showinfo("OK", f"Importación Excel finalizada. Registros procesados: {total}")
        except Exception as e:
            self.logger.exception("Error durante importación Excel")
            self.ui_log(f"ERROR EXCEL: {e}")
            messagebox.showerror("Error", str(e))
        finally:
            if importer:
                importer.close()

    def start_simatic_import(self):
        files = filedialog.askopenfilenames(
            title="Seleccionar archivos CSV Downtime Simatic",
            filetypes=[("CSV", "*.csv"), ("Todos", "*.*")]
        )
        if not files:
            return

        self.ui_log(f"Archivos CSV Simatic seleccionados: {len(files)}")
        for file in files:
            self.ui_log(f"  - {Path(file).name}")

        threading.Thread(target=self.run_simatic_import, args=(files,), daemon=True).start()

    def run_simatic_import(self, files):
        importer = None
        try:
            self.ui_log("Iniciando importación Downtime Simatic a MySQL...")
            importer = DowntimeSimaticImporter(self.cfg.mysql(), self.logger)
            importer.connect()
            result = importer.import_csv_files(
                files=files,
                batch_size=max(self.cfg.batch_size(), 1000),
                progress_callback=self.ui_log,
            )
            msg = (
                "IMPORTACIÓN DOWNTIME SIMATIC FINALIZADA. "
                f"Leídas: {result['read']} | Válidas: {result['valid']} | "
                f"Nuevas insertadas: {result['inserted']} | "
                f"Duplicadas/ignoradas: {result['duplicates_or_ignored']} | "
                f"Errores: {result['errors']}"
            )
            self.ui_log(msg)
            messagebox.showinfo("OK", msg)
        except Exception as e:
            self.logger.exception("Error durante importación Downtime Simatic")
            self.ui_log(f"ERROR DOWNTIME SIMATIC: {e}")
            messagebox.showerror("Error", str(e))
        finally:
            if importer:
                importer.close()


if __name__ == "__main__":
    app = ImportadorApp()
    app.mainloop()
