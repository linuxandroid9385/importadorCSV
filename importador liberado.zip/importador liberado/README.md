# Importador Universal MySQL v6

Versión actualizada con dos flujos de importación:

1. **Importación universal Excel a MySQL** para tablas existentes con mapeo automático `snake_case` -> `CamelCase`.
2. **Importación Downtime Simatic CSV** mediante botón dedicado en la GUI.

## Downtime Simatic

El botón **Importar Downtime Simatic** permite seleccionar uno o muchos archivos `.csv` con estructura:

```csv
Equipo Name,Start Time,End Time,Duración,Nivel 1,Nivel 2,Nivel 3,Nivel 4,
Planta3/LINEA 9 EVEREST/Prensa-G301,4/2/2026 5:07:47 PM,4/2/2026 5:07:55 PM,.13 Min,...
```

La importación transforma cada fila a la tabla MySQL `downtime_simatic`:

- `planta`
- `linea`
- `equipo`
- `fecha_inicio`
- `fecha_fin`
- `downtime_min`
- `nivel1`
- `nivel2`
- `nivel3`
- `nivel4`
- `archivo_origen`
- `hash_registro`

El importador crea automáticamente la tabla `downtime_simatic` si no existe, usando la estructura solicitada.

## Reglas de transformación Simatic

- `Equipo Name` se separa por `/`:
  - parte 1 -> `planta`
  - parte 2 -> `linea`
  - parte 3 -> `equipo`
- `LINEA9` se normaliza a `LINEA 9`.
- `Duración` acepta valores como `.13 Min`, `2 Min`, `5,89 Min`.
- Fechas con regla antiambigüedad equivalente al VBA:
  - si el primer número es mayor a 12 -> `dd/mm/yyyy`
  - si no -> `mm/dd/yyyy`
- Soporta hora 24h y AM/PM.
- Inserta por lotes para soportar grandes cantidades de archivos CSV.
- Usa `hash_registro` con `UNIQUE KEY` para evitar duplicados.

## Instalación

```bash
pip install -r requirements.txt
```

## Ejecución

Desde la raíz del proyecto:

```bash
python src/main.py
```

También funciona si ejecutas desde `src/`, porque el programa busca `config.ini` junto a `main.py` o en la raíz.

## Configuración

Edita `config.ini` con tu conexión MySQL:

```ini
[mysql]
host = 127.0.0.1
port = 3306
user = root
password = 12345
database = tpm_database
table = work_requests
```
